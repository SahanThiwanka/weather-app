const express = require("express");
const { getWeather } = require("../controllers/weatherController");
const router = express.Router();

// Fetch weather by city name
router.get("/:city", getWeather);

module.exports = router;
